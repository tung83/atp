jQuery(document).ready(function() {

    // page is now ready, initialize the calendar...

    jQuery('#calendar').fullCalendar({
        // put your options and callbacks here
    })

});