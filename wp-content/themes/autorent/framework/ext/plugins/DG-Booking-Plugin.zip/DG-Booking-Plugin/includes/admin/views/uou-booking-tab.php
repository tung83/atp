<li class="bookings_tab uou_bookings_availability_tab advanced_options show_if_uou"><a href="#bookings_availability"><?php _e( 'Availability', 'uou-bookings' ); ?></a></li>
